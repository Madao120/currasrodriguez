<template>
  <div
    class="success-container d-flex justify-content-center align-items-center"
  >
    <div class="success-card card shadow">
      <div class="card-body">
        <h1 class="card-title text-success">Pago Completado!</h1>
        <p class="card-text text-muted">
          Muchas gracias por tu compra. Te hemos enviado un correo con los
          detalles.
        </p>
        <div class="invoice-container mt-4">
          <p class="text-muted">Descargue su factura en formato PDF:</p>
          <button
            @click="generarFacturaPdf"
            class="btn btn-primary mb-2 justify-content-center"
          >
            <i class="bi bi-file-earmark-pdf"></i> Descargar Factura
          </button>
          <router-link
            to="/"
            class="btn btn-outline-primary justify-content-center"
          >
            <i class="bi bi-arrow-left"></i> Volver a la tienda
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { useCestaStore } from "../store/cesta";
import logo from "../assets/logoPng.png";
import { addFactura } from "../api/facturas";
import { updateArticulo } from "../api/articulos";
import { onMounted, ref } from "vue";
import { getClientePorDni } from "../api/clientes";
// Creamos la cesta para usar metodos y datos
const cestaStore = useCestaStore();
cestaStore.completarCompra();
const facturaGuardada = ref(false);
const articulosActualizados = ref(false);
const cliente = ref(null);

const cesta = useCestaStore();

async function guardarFacturaMongo() {
  if (facturaGuardada.value || cestaStore.compraCompleta.length === 0) return;

  try {
    const factura = {
      productos: cestaStore.compraCompleta.map((producto) => ({
        productoId: producto._id || producto.id,
        nombre:
          producto.nombre || `${producto.marca ?? ""} ${producto.modelo ?? ""}`,
        cantidad: producto.cantidad,
        precio_unitario: producto.precio,
      })),
      total: cestaStore.totalPrecio,
    };
    await addFactura(factura);
    facturaGuardada.value = true;
    console.log("Factura guardada en MongoDB");
  } catch (error) {
    console.error("Error guardando la factura", error);
  }
}

onMounted(async () => {
  // Obtener el cliente logeado por su DNI
  const userDNI = sessionStorage.getItem("userDNI");
  if (userDNI) {
    try {
      cliente.value = await getClientePorDni(userDNI);
      console.log("Cliente obtenido:", cliente.value);
    } catch (error) {
      console.error("Error obteniendo cliente:", error);
    }
  }

  await guardarFacturaMongo();
  await marcarArticulosVendidos();
});

async function marcarArticulosVendidos() {
  if (articulosActualizados.value || cestaStore.compraCompleta.length === 0) {
    return;
  }

  try {
    const actualizaciones = cestaStore.compraCompleta.map((producto) => {
      const id = producto._id || producto.id;
      if (!id) return null;
      return updateArticulo(id, { estado: "vendido" });
    });

    await Promise.all(actualizaciones.filter(Boolean));
    articulosActualizados.value = true;
  } catch (error) {
    console.error("Error actualizando estado de articulos:", error);
  }
}

//Metodo que genera un pdf en base a los datos que le pasamos.
async function generarFacturaPdf() {
  //Asociamos el array de items no visible a la variable cart
  const cart = cestaStore.compraCompleta;

  //Si no tiene elementos mostramos alert
  if (cart.length === 0) {
    alert("No hay productos para facturar");
    return;
  }

  //Creamos pdf y seteamos las propiedades
  const doc = new jsPDF();

  // Logo y encabezado
  doc.addImage(logo, "png", 10, 10, 20, 20);
  doc.setFontSize(18);
  doc.text("Factura de Compra", 60, 20);
  doc.setFontSize(9);
  doc.text("Razón Social: Regalos Teis", 110, 50);
  doc.text("Dirección: Avenida Galicia 101, Vigo - 36216", 110, 55);
  doc.text("Tlfo: 986 666 333 - Email: regalos@example.com", 110, 60);

  doc.setFontSize(9);
  doc.text(`DNI: ${cliente.value?.dni || "N/A"}`, 10, 80);
  doc.text(`Nombre: ${cliente.value?.nombre || "N/A"}`, 10, 90);
  doc.text(`Email: ${cliente.value?.email || "N/A"}`, 10, 100);

  // Tabla de productos, marcará los headers de cada tabla
  const headers = [["ID", "Producto", "Cantidad", "Precio Unitario", "Total"]];
  //Formatea los datos para ser visibles, es un array de objetos
  const data = cart.map((item) => [
    item.id,
    item.nombre,
    item.cantidad,
    `${item.precio.toFixed(2)}€`,
    `${(item.cantidad * item.precio).toFixed(2)}€`,
  ]);

  //Creamos tabla en base a los headers y datos
  autoTable(doc, {
    startY: 110,
    head: headers,
    body: data,
    columnStyles: {
      0: { halign: "center" },
      2: { halign: "center" },
      3: { halign: "right" },
      4: { halign: "right" },
    },
    theme: "striped",
  });

  // Coger los datos para poner en el documento, el total vendrá del compraCompleta ya que el otro estará vacío
  const totalPrice = cestaStore.totalPrecio;
  const totalText = `Total: ${cesta.precioFinal}€`;
  const pageWidth = doc.internal.pageSize.width;
  const totalWidth = doc.getTextWidth(totalText);
  const positionX = pageWidth - totalWidth - 14;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text(totalText, positionX - 9, doc.lastAutoTable.finalY + 10);

  //Guardamos el pdf
  doc.save("factura.pdf");

  //Limpuamos ambas listas y el sessionStorage
  cestaStore.clearCesta();
}
</script>
<style scoped>
.success-container {
  min-height: 80vh;
  padding: 20px;
}

.success-card {
  max-width: 500px;
  border-radius: 8px;
}

.invoice-container {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  text-decoration: none;
}

router-link {
  text-decoration: none;
}
</style>
